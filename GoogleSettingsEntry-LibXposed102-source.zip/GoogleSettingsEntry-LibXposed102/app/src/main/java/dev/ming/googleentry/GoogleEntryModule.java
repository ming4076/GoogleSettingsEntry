package dev.ming.googleentry;

import android.util.Log;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface.PackageLoadedParam;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Restores the stock MIUI Google header by invoking the method already
 * implemented by the target Settings APK.
 *
 * Target verified against the user-provided Settings APK:
 *   com.android.settings.MiuiSettings
 *   updateHeaderList(java.util.List): void
 *   AddGoogleSettingsHeaders(java.util.List): void
 */
public final class GoogleEntryModule extends XposedModule {
    private static final String TAG = "GoogleEntry102";
    private static final String TARGET_PACKAGE = "com.android.settings";
    private static final String TARGET_CLASS = "com.android.settings.MiuiSettings";
    private static final String HEADER_CLASS =
            "com.android.settingslib.miuisettings.preference.PreferenceActivity$Header";
    private static final String RESOURCE_CLASS = "com.android.settings.R$id";

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        if (!TARGET_PACKAGE.equals(param.getPackageName())) {
            return;
        }

        ClassLoader classLoader = param.getDefaultClassLoader();

        try {
            Class<?> miuiSettings = Class.forName(TARGET_CLASS, false, classLoader);

            // Both method signatures were verified from the supplied Android 17 Settings DEX.
            Method updateHeaderList =
                    miuiSettings.getDeclaredMethod("updateHeaderList", List.class);
            Method addGoogleHeaders =
                    miuiSettings.getDeclaredMethod("AddGoogleSettingsHeaders", List.class);

            updateHeaderList.setAccessible(true);
            addGoogleHeaders.setAccessible(true);

            hook(updateHeaderList)
                    .setId("google-settings-entry-update-header-list")
                    .intercept(chain -> {
                        // Preserve the stock Settings header-building behavior first.
                        Object result = chain.proceed();

                        Object settingsInstance = chain.getThisObject();
                        Object arg = chain.getArg(0);

                        if (settingsInstance == null || !(arg instanceof List<?>)) {
                            return result;
                        }

                        List<?> headers = (List<?>) arg;

                        // On global builds the stock method may already have inserted
                        // the Google header. Do not add it a second time.
                        if (containsGoogleHeader(headers, classLoader)) {
                            return result;
                        }

                        try {
                            addGoogleHeaders.invoke(settingsInstance, headers);
                            log(Log.INFO, TAG, "Native Google header method invoked.");
                        } catch (InvocationTargetException e) {
                            Throwable cause = e.getCause() != null ? e.getCause() : e;
                            log(Log.ERROR, TAG, "AddGoogleSettingsHeaders failed.", cause);
                        } catch (Throwable t) {
                            log(Log.ERROR, TAG, "Unable to invoke native Google header method.", t);
                        }

                        return result;
                    });

            log(Log.INFO, TAG, "Hook installed on MiuiSettings.updateHeaderList(List).");
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Hook installation failed for this Settings build.", t);
        }
    }

    private static boolean containsGoogleHeader(List<?> headers, ClassLoader classLoader) {
        try {
            Class<?> resourceClass = Class.forName(RESOURCE_CLASS, false, classLoader);
            Field resourceIdField =
                    resourceClass.getDeclaredField("header_google_settings");
            resourceIdField.setAccessible(true);
            long expectedId = ((Number) resourceIdField.get(null)).longValue();

            Class<?> headerClass = Class.forName(HEADER_CLASS, false, classLoader);
            Field headerIdField = findField(headerClass, "id");
            if (headerIdField == null) {
                return false;
            }
            headerIdField.setAccessible(true);

            for (Object header : headers) {
                if (header == null || !headerClass.isInstance(header)) {
                    continue;
                }
                Object value = headerIdField.get(header);
                if (value instanceof Number
                        && ((Number) value).longValue() == expectedId) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
            // If the duplicate check cannot be performed, the native method is
            // still called. The target ROM is expected to be the China build.
        }
        return false;
    }

    private static Field findField(Class<?> type, String name) {
        Class<?> current = type;
        while (current != null) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }
}
