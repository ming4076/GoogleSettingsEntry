package dev.ming.googleentry;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Google 设置入口");
        title.setTextSize(22);
        root.addView(title);

        TextView body = new TextView(this);
        body.setText(
                "模块使用 libxposed Modern API 102。\n\n"
                + "启用步骤：\n"
                + "1. 在 LSPosed 中启用本模块。\n"
                + "2. 作用域只选择 com.android.settings。\n"
                + "3. 强制停止或重启“设置”应用。\n"
                + "4. 打开设置首页检查 Google 入口。\n\n"
                + "本模块调用 Settings 自带的 AddGoogleSettingsHeaders(List)，"
                + "不会自行伪造 Google Activity。\n\n"
                + "若入口仍未出现，请确认 Google Play 服务已安装，且系统中存在"
                + "符合小米筛选条件的 Google 设置 Activity。"
        );
        body.setTextSize(16);
        body.setPadding(0, pad, 0, 0);
        root.addView(body);

        setContentView(root);
    }
}
