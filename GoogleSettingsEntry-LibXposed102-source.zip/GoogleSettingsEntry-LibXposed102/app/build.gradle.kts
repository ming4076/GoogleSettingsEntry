plugins {
    id("com.android.application")
}

android {
    namespace = "dev.ming.googleentry"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.ming.googleentry"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    // Modern LSPosed / libxposed API 102
    compileOnly("io.github.libxposed:api:102.0.0")
}
